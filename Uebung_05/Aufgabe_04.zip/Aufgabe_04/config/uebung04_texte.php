<?php

//////////////////////////////////////////////////
//  Übung 05 - 04    - uebung04_texte.php       //
//  Fachbereich Medien FH-Kiel - 3. Semester    //
//  Beschreibung : arrays/multipage             //
//  Ersteller    : Jannik Sievert               //
//  Stand        : 12.10.2018                   //
//  Version      : 1.0                          //
//////////////////////////////////////////////////

$browsersprache = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,2);

$lang =    array(

    array(
        
        "Wähle eine Sprache aus!",
        "Wochentage",
        "Zusammenfassung der Variablen:",
        "Die gewählte Sprache ist >>> 0",
        "Die browser-Sprache ist >>> ".$browsersprache,
        "Sonntag",
        "Montag",
        "Dienstag",
        "Mittwoch",
        "Donnerstag",
        "Freitag",
        "Samstag",
        "Seite 1",
        "Seite 2"
    ),

    array(

        "Choose a language!",
        "Weekdays",
        "Summary of variables:",
        "the selected language is >>> 1",
        "the browser language is >>> ".$browsersprache,
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturay",     
        "Side 1",
        "Side 2"
    ) 
);

?>